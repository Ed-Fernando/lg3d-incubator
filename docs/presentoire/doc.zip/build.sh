#!/bin/bash

zip doc.zip *